/*
 * Copyright (c) 2020, TheStonedTurtle <https://github.com/TheStonedTurtle>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.dmsafe.partypanel.ui;

import com.dmsafe.DMSafePlugin;
import com.dmsafe.partypanel.data.PartyPlayer;
import com.dmsafe.rsnoverlay.PlayerRankImage;
import com.google.common.base.Strings;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.OverlayLayout;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;

import lombok.Getter;
import lombok.Setter;
import net.runelite.api.Constants;
import net.runelite.api.Skill;
import net.runelite.api.SpriteID;
import net.runelite.client.game.ChatIconManager;
import net.runelite.client.game.SpriteManager;
import net.runelite.client.ui.ColorScheme;
import net.runelite.client.ui.PluginPanel;
import net.runelite.client.util.ImageUtil;

public class PlayerBanner extends JPanel {
    private static final Dimension STAT_ICON_SIZE = new Dimension(18, 18);
    private static final Dimension ICON_SIZE = new Dimension(Constants.ITEM_SPRITE_WIDTH - 6, Constants.ITEM_SPRITE_HEIGHT - 4);
    private static final BufferedImage EXPAND_ICON = ImageUtil.loadImageResource(DMSafePlugin.class, "expand.png");
    private static final String SPECIAL_ATTACK_NAME = "Special Attack";

    @Getter
    private final JPanel statsPanel = new JPanel();
    private final JLabel iconLabel = new JLabel();
    private final Map<String, JLabel> statLabels = new HashMap<>();
    private final Map<String, JLabel> iconLabels = new HashMap<>();
    @Getter
    private final JLabel expandIcon = new JLabel();
    private final JLabel worldLabel = new JLabel();

    private final ImageIcon expandIconUp;
    private final ImageIcon expandIconDown;

    @Setter
    @Getter
    private PartyPlayer player;
    private final PlayerRankImage playerRankImage;
    private boolean checkIcon;
    private BufferedImage currentHeart = null;

    public PlayerBanner(final PartyPlayer player, boolean expanded, boolean displayWorld, SpriteManager spriteManager, DMSafePlugin plugin, ChatIconManager chatIconManager) {
        super();
        this.player = player;
        this.setLayout(new GridBagLayout());
        this.setPreferredSize(new Dimension(PluginPanel.PANEL_WIDTH - 14, 68));
        this.setBorder(new EmptyBorder(5, 5, 0, 5));

        playerRankImage = new PlayerRankImage(chatIconManager);

        statsPanel.setPreferredSize(new Dimension(PluginPanel.PANEL_WIDTH, 25));
        statsPanel.setLayout(new GridLayout(0, 4));
        statsPanel.setBorder(new EmptyBorder(5, 0, 0, 0));
        statsPanel.setOpaque(true);

        expandIconDown = new ImageIcon(EXPAND_ICON);
        expandIconUp = new ImageIcon(ImageUtil.rotateImage(EXPAND_ICON, Math.PI));
        if (expanded) {
            expandIcon.setIcon(expandIconUp);
        } else {
            expandIcon.setIcon(expandIconDown);
        }

        worldLabel.setHorizontalTextPosition(JLabel.LEFT);
        worldLabel.setVisible(displayWorld);

        statsPanel.add(createIconPanel(spriteManager, SpriteID.SKILL_HITPOINTS, Skill.HITPOINTS.getName(), String.valueOf(player.getSkillBoostedLevel(Skill.HITPOINTS)), false));
        statsPanel.add(createIconPanel(spriteManager, SpriteID.SKILL_PRAYER, Skill.PRAYER.getName(), String.valueOf(player.getSkillBoostedLevel(Skill.PRAYER)), false));
        statsPanel.add(createIconPanel(spriteManager, SpriteID.MULTI_COMBAT_ZONE_CROSSED_SWORDS, SPECIAL_ATTACK_NAME, player.getStats() == null ? "0" : String.valueOf(player.getStats().getSpecialPercent()), false));
        statsPanel.add(createIconPanel(spriteManager,
                player.getVengActive() == 1 ? SpriteID.SPELL_VENGEANCE : SpriteID.SPELL_VENGEANCE_DISABLED,
                "VengChecker", "", true));

        recreatePanel(plugin);
    }

    public void recreatePanel(DMSafePlugin plugin) {
        plugin.addUsersToLog();
        removeAll();

        final GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.NORTHWEST;
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0;
        c.weighty = 1.0;
        c.ipady = 4;

        // Add avatar label regardless of if one exists just to have UI matching
        iconLabel.setBorder(new MatteBorder(1, 1, 1, 1, ColorScheme.DARKER_GRAY_HOVER_COLOR));
        iconLabel.setPreferredSize(ICON_SIZE);
        iconLabel.setMinimumSize(ICON_SIZE);
        iconLabel.setOpaque(false);

        checkIcon = player.getMember().getAvatar() == null;
        if (!checkIcon) {
            addIcon();
        }

        add(iconLabel, c);
        c.gridx++;

        final JPanel nameContainer = new JPanel(new GridLayout(2, 1));
        nameContainer.setBorder(new EmptyBorder(0, 5, 0, 0));
        nameContainer.setOpaque(false);

        final JLabel usernameLabel = new JLabel();
        usernameLabel.setLayout(new OverlayLayout(usernameLabel));
        usernameLabel.setHorizontalTextPosition(JLabel.RIGHT);
        if (Strings.isNullOrEmpty(player.getUsername())) {
            usernameLabel.setText("Not logged in");
        } else {
            final String levelText = player.getStats() == null ? "" : " (level-" + player.getStats().getCombatLevel() + ")";
            usernameLabel.setText(player.getUsername() + levelText);
            usernameLabel.setForeground(plugin.data.getColor(player.getUsername()));
            BufferedImage rankImage = playerRankImage.getRankImage(plugin, player.getUsername());
            usernameLabel.setIcon(new ImageIcon(rankImage));
        }

        expandIcon.setAlignmentX(Component.RIGHT_ALIGNMENT);
        usernameLabel.add(expandIcon, BorderLayout.EAST);
        nameContainer.add(usernameLabel);

        worldLabel.setText("Not logged in");
        if (Strings.isNullOrEmpty(player.getUsername())) {
            worldLabel.setText("");
        } else if (player.getWorld() > 0) {
            worldLabel.setText("World " + player.getWorld());
        }
        nameContainer.add(worldLabel);

        c.weightx = 1.0;
        c.fill = GridBagConstraints.HORIZONTAL;
        add(nameContainer, c);

        refreshStats();
        c.gridy++;
        c.weightx = 0;
        c.gridx = 0;
        c.gridwidth = 2;
        add(statsPanel, c);

        revalidate();
        repaint();
    }

    private void addIcon() {
        final BufferedImage resized = ImageUtil.resizeImage(player.getMember().getAvatar(), Constants.ITEM_SPRITE_WIDTH - 8, Constants.ITEM_SPRITE_HEIGHT - 4);
        iconLabel.setIcon(new ImageIcon(resized));
    }

    public void refreshVeng(boolean venged, SpriteManager spriteManager) {
        if (venged) {
            setSpriteIcon("VengChecker", SpriteID.SPELL_VENGEANCE, spriteManager);
        } else {
            setSpriteIcon("VengChecker", SpriteID.SPELL_VENGEANCE_DISABLED, spriteManager);
        }

        statsPanel.revalidate();
        statsPanel.repaint();
    }

    public void setExpandIcon(boolean direction) {
        if (direction) {
            expandIcon.setIcon(expandIconUp);
        } else {
            expandIcon.setIcon(expandIconDown);
        }
    }

    public void refreshStats() {
        if (checkIcon) {
            if (player.getMember().getAvatar() != null) {
                addIcon();
                checkIcon = false;
            }
        }

        statLabels.getOrDefault(Skill.HITPOINTS.getName(), new JLabel()).setText(String.valueOf(player.getSkillBoostedLevel(Skill.HITPOINTS)));
        statLabels.getOrDefault(Skill.PRAYER.getName(), new JLabel()).setText(String.valueOf(player.getSkillBoostedLevel(Skill.PRAYER)));
        statLabels.getOrDefault(SPECIAL_ATTACK_NAME, new JLabel()).setText(player.getStats() == null ? "0" : String.valueOf(player.getStats().getSpecialPercent()));

        statsPanel.revalidate();
        statsPanel.repaint();
    }

    private JPanel createIconPanel(final SpriteManager spriteManager, final int spriteID, final String name,
                                   final String value, boolean centerImage) {
        final JLabel iconLabel = new JLabel();
        iconLabel.setPreferredSize(STAT_ICON_SIZE);
        iconLabels.put(name, iconLabel);
        setSpriteIcon(name, spriteID, spriteManager);

        final JLabel textLabel = new JLabel(value);
        textLabel.setHorizontalAlignment(JLabel.CENTER);
        textLabel.setHorizontalTextPosition(JLabel.CENTER);
        statLabels.put(name, textLabel);

        final JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(iconLabel, centerImage ? BorderLayout.CENTER : BorderLayout.WEST);
        if (!centerImage) {
            panel.add(textLabel, BorderLayout.CENTER);
        }
        panel.setOpaque(false);
        panel.setToolTipText(name);

        return panel;
    }

    private void setSpriteIcon(String statLabelKey, final int spriteID, final SpriteManager spriteManager) {
        final JLabel label = iconLabels.get(statLabelKey);
        spriteManager.getSpriteAsync(spriteID, 0, img ->
                SwingUtilities.invokeLater(() -> {
                    if (spriteID == SpriteID.SKILL_PRAYER) {
                        label.setIcon(new ImageIcon(ImageUtil.resizeImage(img, STAT_ICON_SIZE.width + 2, STAT_ICON_SIZE.height + 2)));
                    } else {
                        label.setIcon(new ImageIcon(ImageUtil.resizeImage(img, STAT_ICON_SIZE.width, STAT_ICON_SIZE.height)));
                    }
                    label.revalidate();
                    label.repaint();
                }));
    }

    private void setBufferedIcon(String statLabelKey, final BufferedImage img) {
        final JLabel label = iconLabels.get(statLabelKey);
        SwingUtilities.invokeLater(() ->
        {
            label.setIcon(new ImageIcon(ImageUtil.resizeImage(img, STAT_ICON_SIZE.width, STAT_ICON_SIZE.height)));
            label.revalidate();
            label.repaint();
        });
    }

    public void setCurrentHeart(final BufferedImage img, SpriteManager spriteManager) {
        // If the new value is the same then do nothing
        if ((img == null && currentHeart == null) || (img != null && img.equals(currentHeart))) {
            return;
        }
        currentHeart = img;
        if (currentHeart == null) {
            setSpriteIcon(Skill.HITPOINTS.getName(), SpriteID.SKILL_HITPOINTS, spriteManager);
        } else {
            setBufferedIcon(Skill.HITPOINTS.getName(), currentHeart);
        }
        statsPanel.revalidate();
        statsPanel.repaint();
    }

}