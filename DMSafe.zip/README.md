# DMSafe
A plugin to track DMSafe Ranks & players who scam in Deathmatching.

Feature List:
- Access Data list end point to grab current usernames of ranks & scammers
- See Rank & Scammer names + icons above their heads 
- See Rank names on the minimap
- Write in the chat box when a scammer is nearby
- Join Discord Buttons
- Display current CC Name
- Built in Video Recorder
- HWID & Account ID Tracking
- 
- Features (Thanks to StonedTurtle for making the Party Hub P)
- Join Party Button
- View Prayers
- View Skills & Boosts
- View Equipment
- View Inventory

To-do List:
- Challenge in DM on user right click to automatically join a Party
- Party passphrases (challenge will just write bot RSNs in & collect IDs of both players)
- View Player Icon on the side, defaulting to just Deathmatcher icon if they are not in the system
