# DMSafe
A plugin to track DMSafe Ranks & players who scam in Deathmatching.

Feature List:
- Access Data list end point to grab current usernames of Ranks & Scammers
- Toggleable option to See Rank & Scammer names + icons above their heads 
- Toggleable option to See Rank names on the minimap
- Toggleable option to Write in the chat box when a scammer is nearby
- HWID & Account ID Tracking
- Display current CC Name
- Join & Leave Party Buttons
- Join Discord Button
- DMSafe Party Button
- Logs Button
- View Prayers
- View Skills & Boosts
- View Equipment
- View Inventory
- Deathmatch on user right click to automatically join a Party
- Party passphrases (challenge will just write both RSNs in & collect IDs of both players)
- Displays what Rank someone is in the Plugin on Challenge